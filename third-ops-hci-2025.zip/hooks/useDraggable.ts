
import { useRef, useEffect, useCallback } from 'react';
import type React from 'react';

export const useDraggable = (modalRef: React.RefObject<HTMLDivElement>, handleRef: React.RefObject<HTMLElement>) => {
  const isDragging = useRef(false);
  const startPos = useRef({ x: 0, y: 0 });
  const initialModalPos = useRef({ x: 0, y: 0 });

  const onMouseDown = useCallback((e: MouseEvent) => {
    if (modalRef.current && handleRef.current && handleRef.current.contains(e.target as Node)) {
      isDragging.current = true;
      modalRef.current.classList.add('dragging');
      
      const rect = modalRef.current.getBoundingClientRect();
      initialModalPos.current = { x: rect.left, y: rect.top };
      startPos.current = { x: e.clientX, y: e.clientY };
      
      // Switch to absolute positioning via inline styles to avoid class conflicts
      modalRef.current.style.position = 'fixed';
      modalRef.current.style.left = `${initialModalPos.current.x}px`;
      modalRef.current.style.top = `${initialModalPos.current.y}px`;
      modalRef.current.style.right = 'auto';
      modalRef.current.style.bottom = 'auto';
      modalRef.current.style.transform = 'none'; // Clear any transform

      e.preventDefault();
    }
  }, [modalRef, handleRef]);

  const onMouseMove = useCallback((e: MouseEvent) => {
    if (isDragging.current && modalRef.current) {
      const dx = e.clientX - startPos.current.x;
      const dy = e.clientY - startPos.current.y;
      
      modalRef.current.style.left = `${initialModalPos.current.x + dx}px`;
      modalRef.current.style.top = `${initialModalPos.current.y + dy}px`;
    }
  }, []);

  const onMouseUp = useCallback(() => {
    if (isDragging.current && modalRef.current) {
      isDragging.current = false;
      modalRef.current.classList.remove('dragging');
    }
  }, []);

  useEffect(() => {
    const handleElement = handleRef.current;
    if (handleElement) {
      handleElement.addEventListener('mousedown', onMouseDown);
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);

      return () => {
        handleElement.removeEventListener('mousedown', onMouseDown);
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
      };
    }
  }, [handleRef, onMouseDown, onMouseMove, onMouseUp]);
};