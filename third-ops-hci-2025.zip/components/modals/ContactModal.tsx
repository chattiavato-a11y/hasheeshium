
import React, { useContext, useRef } from 'react';
import { GlobalContext } from '../../contexts/GlobalContext';
import { useDraggable } from '../../hooks/useDraggable';
import type { ModalProps } from '../../types';
import ModalWrapper from './ModalWrapper';

const ContactModal: React.FC<ModalProps> = ({ isOpen, onClose, showBackdrop = true }) => {
  const { language } = useContext(GlobalContext);
  const modalRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  useDraggable(modalRef, headerRef);

  const l = (en: string, es: string) => language === 'en' ? en : es;
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Form submitted! We will contact you shortly.');
    onClose();
  };

  const initialPosition = !showBackdrop ? 'right-4 bottom-28' : '';

  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose} showBackdrop={showBackdrop} modalClassName={`w-[96vw] max-w-lg min-w-[310px] ${initialPosition}`}>
      <div ref={modalRef} className="bg-white dark:bg-dark-modal text-light-text dark:text-dark-text rounded-3xl shadow-2xl p-6 relative max-h-[80vh] flex flex-col">
        <header ref={headerRef} className="flex justify-between items-center pb-4 border-b border-gray-200 dark:border-gray-700 cursor-move">
          <h2 className="text-2xl font-bold text-primary">{l('Contact Us', 'Contáctenos')}</h2>
          <button onClick={onClose} className="text-3xl font-bold text-accent/80 hover:text-accent">&times;</button>
        </header>

        <form onSubmit={handleSubmit} className="space-y-4 overflow-y-auto flex-grow pr-2 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
            <div>
              <label htmlFor="contact-name" className="block text-sm font-medium mb-1">{l('Name', 'Nombre')}</label>
              <input type="text" id="contact-name" placeholder={l('Enter your name', 'Ingrese su nombre')} required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary focus:border-transparent"/>
            </div>
            <div>
              <label htmlFor="contact-email" className="block text-sm font-medium mb-1">{l('Email', 'Correo Electrónico')}</label>
              <input type="email" id="contact-email" placeholder={l('Enter your email', 'Ingrese su correo')} required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary focus:border-transparent"/>
            </div>
            <div>
              <label htmlFor="contact-number" className="block text-sm font-medium mb-1">{l('Contact Number', 'Número de Contacto')}</label>
              <input type="tel" id="contact-number" placeholder={l('Enter your number', 'Ingrese su número')} required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary focus:border-transparent"/>
            </div>
            <div>
              <label htmlFor="preferred-date" className="block text-sm font-medium mb-1">{l('Preferred Date', 'Fecha Preferida')}</label>
              <input type="date" id="preferred-date" required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary focus:border-transparent"/>
            </div>
            <div>
              <label htmlFor="preferred-time" className="block text-sm font-medium mb-1">{l('Preferred Time', 'Hora Preferida')}</label>
              <input type="time" id="preferred-time" required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary focus:border-transparent"/>
            </div>
            <div>
              <label htmlFor="interest" className="block text-sm font-medium mb-1">{l('I am interested in...', 'Estoy interesado en...')}</label>
              <select id="interest" required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary focus:border-transparent">
                  <option value="" disabled selected>{l('Select a service', 'Seleccione un servicio')}</option>
                  <option>{l('Business Operations', 'Operaciones Empresariales')}</option>
                  <option>{l('Contact Center', 'Centro de Contacto')}</option>
                  <option>{l('IT Support', 'Soporte IT')}</option>
                  <option>{l('Professionals', 'Profesionales')}</option>
              </select>
            </div>
          </div>

          <div className="pt-2">
            <label htmlFor="contact-comments" className="block text-sm font-medium mb-1">{l('Comments', 'Comentarios')}</label>
            <textarea id="contact-comments" rows={4} placeholder={l('How can we help you?', '¿Cómo podemos ayudarle?')} required className="w-full p-2 rounded-md bg-gray-100 dark:bg-gray-700 border-transparent focus:ring-2 focus:ring-primary focus:border-transparent"></textarea>
          </div>

          <div className="flex justify-center gap-3 pt-6 mt-4 border-t border-gray-200 dark:border-gray-700">
            <button type="button" onClick={onClose} className="py-3 px-8 rounded-xl bg-gray-200 dark:bg-gray-600 font-semibold hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors">{l('Cancel', 'Cancelar')}</button>
            <button type="submit" className="py-3 px-8 rounded-xl bg-primary text-white font-semibold hover:bg-cyan-500 transition-colors shadow-lg hover:shadow-xl">{l('Send', 'Enviar')}</button>
          </div>
        </form>
      </div>
    </ModalWrapper>
  );
};

export default ContactModal;