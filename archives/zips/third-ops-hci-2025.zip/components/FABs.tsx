import React, { useState, useEffect, useRef } from 'react';
import type { ModalType } from '../types';

interface FABsProps {
  onOpenModal: (type: ModalType) => void;
  onToggleServicesMenu: () => void;
}

const FABs: React.FC<FABsProps> = ({ onOpenModal, onToggleServicesMenu }) => {
  const [isOpen, setIsOpen] = useState(false);
  const fabContainerRef = useRef<HTMLDivElement>(null);

  // Expanded actions to include Home and Services, replacing MobileNav
  const fabActions = [
    { type: 'HOME', icon: 'fa-home', title: 'Home' },
    { type: 'SERVICES', icon: 'fa-layer-group', title: 'Services' },
    { type: 'CHAT', icon: 'fa-comments', title: 'Chat with Chattia' },
    { type: 'JOIN', icon: 'fa-user-plus', title: 'Join Our Team' },
    { type: 'CONTACT', icon: 'fa-envelope', title: 'Contact Us' },
  ] as const;

  const toggleMenu = () => setIsOpen(!isOpen);

  useEffect(() => {
    if (!isOpen) return;

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    const handleClickOutside = (e: MouseEvent) => {
      if (fabContainerRef.current && !fabContainerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', handleEscape);
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Centralized handler for all FAB actions, incorporating logic from the old MobileNav
  const handleActionClick = (type: typeof fabActions[number]['type']) => {
    setIsOpen(false); // Close menu on action
    switch (type) {
      case 'HOME':
        window.scrollTo({ top: 0, behavior: 'smooth' });
        break;
      case 'SERVICES':
        onToggleServicesMenu();
        break;
      case 'CHAT':
      case 'JOIN':
      case 'CONTACT':
        onOpenModal(type);
        break;
      default:
        break;
    }
  };

  return (
    // Removed responsive hiding classes to enable on all screen sizes
    // Adjusted position for better mobile layout
    <div ref={fabContainerRef} className="fixed bottom-20 right-5 lg:bottom-10 lg:right-10 z-50">
      <div className="relative">
        {isOpen && (
          <div className="flex flex-col items-center mb-4 space-y-3">
            {fabActions.map((action, index) => (
              <button
                key={action.type}
                style={{ animationDelay: `${index * 50}ms`}}
                onClick={() => handleActionClick(action.type)}
                className="w-14 h-14 rounded-full bg-accent text-white shadow-lg flex items-center justify-center transition-transform transform hover:scale-110 opacity-0 animate-fab-in"
                title={action.title}
              >
                <i className={`fas ${action.icon} text-xl`}></i>
              </button>
            ))}
          </div>
        )}
        <button
          onClick={toggleMenu}
          className="w-16 h-16 rounded-full bg-primary text-white shadow-xl flex items-center justify-center transition-all duration-300 transform hover:scale-110 focus:outline-none hover:bg-accent"
          aria-label="Toggle action menu"
          aria-expanded={isOpen}
        >
          <i className={`fas ${isOpen ? 'fa-times' : 'fa-plus'} text-2xl transition-transform duration-300 ease-in-out ${isOpen ? 'rotate-45' : ''}`}></i>
        </button>
      </div>
    </div>
  );
};

export default FABs;