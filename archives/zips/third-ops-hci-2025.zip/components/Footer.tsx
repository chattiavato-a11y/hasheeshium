import React from 'react';
import type { ModalType } from '../types';

interface FooterProps {
  onOpenModal: (type: ModalType) => void;
}

const Footer: React.FC<FooterProps> = ({ onOpenModal }) => {
  return (
    <footer className="w-full bg-white/20 dark:bg-dark-footer/50 backdrop-blur-lg text-gray-800 dark:text-white text-sm rounded-t-2xl border-t border-white/30 dark:border-white/10">
      <div className="w-full max-w-6xl mx-auto flex items-center justify-between p-4 sm:px-8">
        <span className="font-medium tracking-wide">© 2025 OPS Online Support™</span>
        <div className="flex items-center gap-4 sm:gap-6 font-semibold">
          <button onClick={() => onOpenModal('FEEDBACK')} className="hover:text-primary transition-colors">User Feedback</button>
          <button onClick={() => onOpenModal('TERMS')} className="hover:text-primary transition-colors">T & C</button>
          <button onClick={() => onOpenModal('PRIVACY')} className="hover:text-primary transition-colors">Cookie Consent</button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;