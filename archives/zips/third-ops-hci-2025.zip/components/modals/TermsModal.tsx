import React, { useRef, useContext } from 'react';
import type { ModalProps } from '../../types';
import ModalWrapper from './ModalWrapper';
import { useMovable } from '../../hooks/useMovable';
import { GlobalContext } from '../../contexts/GlobalContext';

const TermsModal: React.FC<ModalProps> = ({ isOpen, onClose, showBackdrop }) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const resizeHandleRef = useRef<HTMLDivElement>(null);
  useMovable(modalRef, headerRef, resizeHandleRef);
  const { language } = useContext(GlobalContext);

  const content = {
    en: { title: "Terms & Conditions" },
    es: { title: "Términos y Condiciones" }
  };
  
  const currentContent = content[language];

  const renderContent = () => (
    <div className="prose">
      <p className="text-xs italic">Last updated: {new Date().toLocaleDateString()}</p>
      <p>Please read these terms and conditions carefully before using Our Service.</p>

      <h2 id="introduction">Introduction</h2>
      <p>Welcome to OPS Online Support™. These Terms and Conditions govern your use of our website and services. By accessing or using the service, you agree to be bound by these Terms. If you disagree with any part of the terms, then you may not access the service.</p>
      
      <h2 id="use-of-service">Use of Service</h2>
      <p>You agree to use our services only for lawful purposes. You are prohibited from using the site to post or transmit any material which is or which encourages conduct that would be considered a criminal offense, give rise to civil liability, or otherwise violate any law.</p>
      
      <h2 id="intellectual-property">Intellectual Property</h2>
      <p>The Service and its original content, features, and functionality are and will remain the exclusive property of OPS Online Support™ and its licensors. The Service is protected by copyright, trademark, and other laws of both the United States and foreign countries.</p>
      
      <h2 id="disclaimer">Disclaimer</h2>
      <p>The service is provided on an "AS IS" and "AS AVAILABLE" basis. The service is provided without warranties of any kind, whether express or implied. This is a demonstration application and not a real service.</p>

      <h2 id="limitation-of-liability">Limitation of Liability</h2>
      <p>In no event shall OPS Online Support™, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses.</p>

      <h2 id="governing-law">Governing Law</h2>
      <p>These Terms shall be governed and construed in accordance with the laws of the State of California, without regard to its conflict of law provisions.</p>
      
      <h2 id="changes-to-terms">Changes to Terms</h2>
      <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide at least 30 days' notice prior to any new terms taking effect.</p>
    </div>
  );

  const renderContentEs = () => (
    <div className="prose">
      <p className="text-xs italic">Última actualización: {new Date().toLocaleDateString()}</p>
      <p>Por favor, lea estos términos y condiciones cuidadosamente antes de usar Nuestro Servicio.</p>

      <h2 id="introduccion">Introducción</h2>
      <p>Bienvenido a OPS Online Support™. Estos Términos y Condiciones rigen su uso de nuestro sitio web y servicios. Al acceder o utilizar el servicio, usted acepta estar sujeto a estos Términos. Si no está de acuerdo con alguna parte de los términos, no podrá acceder al servicio.</p>
      
      <h2 id="uso-del-servicio">Uso del Servicio</h2>
      <p>Usted acepta usar nuestros servicios solo para fines lícitos. Se le prohíbe usar el sitio para publicar o transmitir cualquier material que sea o que fomente una conducta que se considere un delito penal, dé lugar a responsabilidad civil o viole cualquier ley.</p>
      
      <h2 id="propiedad-intelectual">Propiedad Intelectual</h2>
      <p>El Servicio y su contenido original, características y funcionalidad son y seguirán siendo propiedad exclusiva de OPS Online Support™ y sus licenciantes. El Servicio está protegido por derechos de autor, marcas comerciales y otras leyes de los Estados Unidos y de otros países.</p>

      <h2 id="descargo-de-responsabilidad">Descargo de Responsabilidad</h2>
      <p>El servicio se proporciona "TAL CUAL" y "SEGÚN DISPONIBILIDAD". El servicio se proporciona sin garantías de ningún tipo, ya sean expresas o implícitas. Esta es una aplicación de demostración y no un servicio real.</p>

      <h2 id="limitacion-de-responsabilidad">Limitación de Responsabilidad</h2>
      <p>En ningún caso OPS Online Support™, ni sus directores, empleados, socios, agentes, proveedores o afiliados, serán responsables de ningún daño indirecto, incidental, especial, consecuente o punitivo, incluyendo, sin limitación, la pérdida de ganancias, datos, uso, buena voluntad u otras pérdidas intangibles.</p>

      <h2 id="ley-aplicable">Ley Aplicable</h2>
      <p>Estos Términos se regirán e interpretarán de acuerdo con las leyes del Estado de California, sin tener en cuenta sus disposiciones sobre conflictos de leyes.</p>
      
      <h2 id="cambios-a-los-terminos">Cambios a los Términos</h2>
      <p>Nos reservamos el derecho, a nuestra entera discreción, de modificar o reemplazar estos Términos en cualquier momento. Proporcionaremos un aviso de al menos 30 días antes de que los nuevos términos entren en vigor.</p>
    </div>
  );

  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose} showBackdrop={showBackdrop} modalClassName="w-auto max-w-2xl min-w-[320px] fixed bottom-24 right-4 lg:bottom-10">
      <div ref={modalRef} style={{ width: '650px', height: '70vh' }} className="bg-white dark:bg-dark-modal text-light-text dark:text-dark-text rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        <div ref={headerRef} className="p-4 bg-gray-100 dark:bg-gray-800 cursor-move flex justify-between items-center shrink-0">
          <h2 className="text-lg font-bold">{currentContent.title}</h2>
          <button onClick={onClose} className="text-xl font-bold text-accent">&times;</button>
        </div>
        <div className="p-6 overflow-y-auto flex-grow bg-gray-50 dark:bg-gray-800/70 no-scrollbar">
          {language === 'en' ? renderContent() : renderContentEs()}
        </div>
        <div ref={resizeHandleRef} className="absolute bottom-1 right-1 w-4 h-4 cursor-se-resize text-gray-400 dark:text-gray-600 hover:text-accent transition-colors">
          <i className="fas fa-expand-alt rotate-90"></i>
        </div>
      </div>
    </ModalWrapper>
  );
};

export default TermsModal;