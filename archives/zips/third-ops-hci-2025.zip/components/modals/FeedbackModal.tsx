import React, { useRef, useContext, useState, useEffect } from 'react';
import type { ModalProps } from '../../types';
import ModalWrapper from './ModalWrapper';
import { useMovable } from '../../hooks/useMovable';
import { GlobalContext } from '../../contexts/GlobalContext';

const FeedbackModal: React.FC<ModalProps> = ({ isOpen, onClose, showBackdrop }) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const resizeHandleRef = useRef<HTMLDivElement>(null);
  useMovable(modalRef, headerRef, resizeHandleRef);
  const { language } = useContext(GlobalContext);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!isOpen) {
        // Reset form state on close
        setTimeout(() => setSubmitted(false), 200);
    }
  }, [isOpen]);

  const content = {
    en: {
      title: "User Feedback",
      nameLabel: "Name (Optional)",
      namePlaceholder: "Your name",
      emailLabel: "Email (Optional)",
      emailPlaceholder: "Your email for follow-up",
      feedbackTypeLabel: "Feedback Type",
      feedbackTypeOptions: ["General Feedback", "Suggestion", "Bug Report"],
      messageLabel: "Message",
      messagePlaceholder: "Tell us what you think...",
      submit: "Submit Feedback",
      submitting: "Submitting...",
      successTitle: "Thank You!",
      successMessage: "Your feedback has been submitted successfully. We appreciate you helping us improve.",
      close: "Close"
    },
    es: {
      title: "Comentarios del Usuario",
      nameLabel: "Nombre (Opcional)",
      namePlaceholder: "Su nombre",
      emailLabel: "Correo (Opcional)",
      emailPlaceholder: "Su correo para seguimiento",
      feedbackTypeLabel: "Tipo de Comentario",
      feedbackTypeOptions: ["Comentario General", "Sugerencia", "Reporte de Error"],
      messageLabel: "Mensaje",
      messagePlaceholder: "Díganos qué piensa...",
      submit: "Enviar Comentarios",
      submitting: "Enviando...",
      successTitle: "¡Gracias!",
      successMessage: "Sus comentarios han sido enviados con éxito. Agradecemos su ayuda para mejorar.",
      close: "Cerrar"
    }
  };

  const currentContent = content[language];

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose} showBackdrop={showBackdrop} modalClassName="w-auto max-w-lg min-w-[320px] fixed bottom-24 right-4 lg:bottom-10">
      <div ref={modalRef} style={{ width: '500px', minHeight: '400px' }} className="bg-white dark:bg-dark-modal text-light-text dark:text-dark-text rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        <div ref={headerRef} className="p-4 bg-gray-100 dark:bg-gray-800 cursor-move flex justify-between items-center shrink-0">
          <h2 className="text-lg font-bold">{submitted ? currentContent.successTitle : currentContent.title}</h2>
          <button onClick={onClose} className="text-xl font-bold text-accent">&times;</button>
        </div>
        <div className="p-6 overflow-y-auto flex-grow bg-gray-50 dark:bg-gray-800/70">
          {submitted ? (
            <div className="flex flex-col items-center justify-center text-center h-full">
              <i className="fas fa-check-circle text-5xl text-green-500 mb-4"></i>
              <p>{currentContent.successMessage}</p>
              <button onClick={onClose} className="mt-6 py-2 px-5 rounded-lg bg-primary text-white hover:bg-accent transition-colors">{currentContent.close}</button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col h-full space-y-4">
              <div>
                <label htmlFor="feedback-name" className="block text-sm font-medium mb-1">{currentContent.nameLabel}</label>
                <input type="text" id="feedback-name" placeholder={currentContent.namePlaceholder} className="w-full p-2 rounded-md bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600" />
              </div>
              <div>
                <label htmlFor="feedback-email" className="block text-sm font-medium mb-1">{currentContent.emailLabel}</label>
                <input type="email" id="feedback-email" placeholder={currentContent.emailPlaceholder} className="w-full p-2 rounded-md bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600" />
              </div>
              <div>
                <label htmlFor="feedback-type" className="block text-sm font-medium mb-1">{currentContent.feedbackTypeLabel}</label>
                <select id="feedback-type" required className="w-full p-2 rounded-md bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600">
                  {currentContent.feedbackTypeOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
              </div>
              <div className="flex-grow flex flex-col">
                <label htmlFor="feedback-message" className="block text-sm font-medium mb-1">{currentContent.messageLabel}</label>
                <textarea id="feedback-message" rows={5} required placeholder={currentContent.messagePlaceholder} className="w-full p-2 rounded-md bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 flex-grow"></textarea>
              </div>
              <div className="mt-4 text-center">
                <button type="submit" className="w-40 h-12 bg-primary border-none rounded-xl text-white font-semibold text-base cursor-pointer shadow-lg hover:bg-accent-dark transition-colors duration-300">
                  {currentContent.submit}
                </button>
              </div>
            </form>
          )}
        </div>
        <div ref={resizeHandleRef} className="absolute bottom-1 right-1 w-4 h-4 cursor-se-resize text-gray-400 dark:text-gray-600 hover:text-accent transition-colors">
          <i className="fas fa-expand-alt rotate-90"></i>
        </div>
      </div>
    </ModalWrapper>
  );
};
export default FeedbackModal;