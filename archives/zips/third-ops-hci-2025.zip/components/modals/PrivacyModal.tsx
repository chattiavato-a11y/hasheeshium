import React, { useRef, useContext } from 'react';
import type { ModalProps } from '../../types';
import ModalWrapper from './ModalWrapper';
import { useMovable } from '../../hooks/useMovable';
import { GlobalContext } from '../../contexts/GlobalContext';

const PrivacyModal: React.FC<ModalProps> = ({ isOpen, onClose, showBackdrop }) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const resizeHandleRef = useRef<HTMLDivElement>(null);
  useMovable(modalRef, headerRef, resizeHandleRef);
  const { language } = useContext(GlobalContext);

  const content = {
    en: { title: "Privacy & Cookie Policy" },
    es: { title: "Política de Privacidad y Cookies" }
  };
  
  const currentContent = content[language];
  
  const renderContent = () => (
    <div className="prose">
      <p className="text-xs italic">Last updated: {new Date().toLocaleDateString()}</p>
      
      <h2 id="introduction">Introduction</h2>
      <p>OPS Online Support™ ("we", "our", "us") is committed to protecting your privacy. This Privacy Policy explains how your personal information is collected, used, and disclosed by us. This Privacy Policy applies to our website and its associated subdomains.</p>
      
      <h2 id="information-we-collect">Information We Collect</h2>
      <p>We may collect information that you provide directly to us, such as when you fill out a contact or feedback form. This may include your name, email address, and any other information you choose to provide. This is a demonstration app and does not store any personal data.</p>
      
      <h2 id="cookies">Cookies and Tracking Technologies</h2>
      <p>We may use cookies to help personalize your online experience. A cookie is a text file that is placed on your hard disk by a web page server. Cookies cannot be used to run programs or deliver viruses to your computer. You have the ability to accept or decline cookies.</p>

      <h2 id="gdpr">Your Rights Under GDPR</h2>
      <p>If you are a resident of the European Economic Area (EEA), you have certain data protection rights. We aim to take reasonable steps to allow you to correct, amend, delete, or limit the use of your Personal Data. These rights include: the right to access, update or delete the information we have on you, the right of rectification, the right to object, the right of restriction, the right to data portability, and the right to withdraw consent.</p>

      <h2 id="ccpa">Your Rights Under CCPA (California)</h2>
      <p>The California Consumer Privacy Act (CCPA) provides California residents with specific rights regarding their personal information. This section describes your CCPA rights and explains how to exercise those rights. You have the right to know what personal information is being collected about you and to request the deletion of your personal information.</p>
      
      <h2 id="security">Data Security</h2>
      <p>We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable.</p>
    </div>
  );

  const renderContentEs = () => (
    <div className="prose">
      <p className="text-xs italic">Última actualización: {new Date().toLocaleDateString()}</p>
      
      <h2 id="introduccion-privacidad">Introducción</h2>
      <p>OPS Online Support™ ("nosotros", "nuestro") se compromete a proteger su privacidad. Esta Política de Privacidad explica cómo se recopila, utiliza y divulga su información personal por nuestra parte. Esta Política de Privacidad se aplica a nuestro sitio web y sus subdominios asociados.</p>
      
      <h2 id="informacion-que-recopilamos">Información que Recopilamos</h2>
      <p>Podemos recopilar información que usted nos proporciona directamente, como cuando completa un formulario de contacto o de comentarios. Esto puede incluir su nombre, dirección de correo electrónico y cualquier otra información que decida proporcionar. Esta es una aplicación de demostración y no almacena ningún dato personal.</p>
      
      <h2 id="cookies-es">Cookies y Tecnologías de Seguimiento</h2>
      <p>Podemos usar cookies para ayudar a personalizar su experiencia en línea. Una cookie es un archivo de texto que un servidor de páginas web coloca en su disco duro. Las cookies no se pueden utilizar para ejecutar programas ni para enviar virus a su ordenador. Usted tiene la posibilidad de aceptar o rechazar las cookies.</p>

      <h2 id="gdpr-es">Sus Derechos bajo el RGPD</h2>
      <p>Si es residente del Espacio Económico Europeo (EEE), tiene ciertos derechos de protección de datos. Nuestro objetivo es tomar medidas razonables para permitirle corregir, modificar, eliminar o limitar el uso de sus Datos Personales. Estos derechos incluyen: el derecho a acceder, actualizar o eliminar la información que tenemos sobre usted, el derecho de rectificación, el derecho de oposición, el derecho de restricción, el derecho a la portabilidad de los datos y el derecho a retirar el consentimiento.</p>

      <h2 id="ccpa-es">Sus Derechos bajo la CCPA (California)</h2>
      <p>La Ley de Privacidad del Consumidor de California (CCPA) otorga a los residentes de California derechos específicos con respecto a su información personal. Esta sección describe sus derechos bajo la CCPA y explica cómo ejercerlos. Tiene derecho a saber qué información personal se recopila sobre usted y a solicitar la eliminación de su información personal.</p>
      
      <h2 id="seguridad-es">Seguridad de los Datos</h2>
      <p>Utilizamos medidas de seguridad administrativas, técnicas y físicas para ayudar a proteger su información personal. Si bien hemos tomado medidas razonables para proteger la información personal que nos proporciona, tenga en cuenta que, a pesar de nuestros esfuerzos, ninguna medida de seguridad es perfecta o impenetrable.</p>
    </div>
  );

  return (
    <ModalWrapper isOpen={isOpen} onClose={onClose} showBackdrop={showBackdrop} modalClassName="w-auto max-w-2xl min-w-[320px] fixed bottom-24 right-4 lg:bottom-10">
      <div ref={modalRef} style={{ width: '650px', height: '70vh' }} className="bg-white dark:bg-dark-modal text-light-text dark:text-dark-text rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        <div ref={headerRef} className="p-4 bg-gray-100 dark:bg-gray-800 cursor-move flex justify-between items-center shrink-0">
          <h2 className="text-lg font-bold">{currentContent.title}</h2>
          <button onClick={onClose} className="text-xl font-bold text-accent">&times;</button>
        </div>
        <div className="p-6 overflow-y-auto flex-grow bg-gray-50 dark:bg-gray-800/70 no-scrollbar">
          {language === 'en' ? renderContent() : renderContentEs()}
        </div>
        <div ref={resizeHandleRef} className="absolute bottom-1 right-1 w-4 h-4 cursor-se-resize text-gray-400 dark:text-gray-600 hover:text-accent transition-colors">
          <i className="fas fa-expand-alt rotate-90"></i>
        </div>
      </div>
    </ModalWrapper>
  );
};

export default PrivacyModal;