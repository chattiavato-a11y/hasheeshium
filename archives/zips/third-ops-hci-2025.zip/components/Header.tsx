import React, { useContext } from 'react';
import { GlobalContext } from '../contexts/GlobalContext';
import { ModalType, ServiceKey } from '../types';

interface HeaderProps {
  onOpenModal: (type: ModalType) => void;
  onNavClick: (serviceKey: ServiceKey) => void;
}

const Header: React.FC<HeaderProps> = ({ onOpenModal, onNavClick }) => {
  const { language, setLanguage, theme, setTheme } = useContext(GlobalContext);

  const toggleLanguage = () => setLanguage(language === 'en' ? 'es' : 'en');
  const toggleTheme = () => setTheme(theme === 'light' ? 'dark' : 'light');

  const navLinks = [
    { en: 'Business Operations', es: 'Operaciones', key: 'ops' as ServiceKey },
    { en: 'Contact Center', es: 'Centro de Contacto', key: 'cc' as ServiceKey },
    { en: 'IT Support', es: 'Soporte IT', key: 'it' as ServiceKey },
    { en: 'Professionals', es: 'Profesionales', key: 'pro' as ServiceKey },
  ];

  return (
    <header className="w-full max-w-6xl mx-auto flex items-center justify-between p-5 sm:px-8 font-semibold bg-transparent">
      <span className="font-bold text-4xl text-accent tracking-widest drop-shadow-logo-glow select-none">OPS</span>
      <nav className="hidden lg:flex gap-9">
        {navLinks.map((link) => (
          <button 
            key={link.key} 
            onClick={() => onNavClick(link.key)}
            className="text-lg relative transition-colors duration-200 hover:text-primary focus:text-primary outline-none group"
          >
            {link[language]}
            <span className="absolute bottom-[-4px] left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full group-focus:w-full"></span>
          </button>
        ))}
      </nav>
      <div className="flex items-center gap-2">
        <button 
          onClick={() => onOpenModal('SEARCH')} 
          title="Search Services"
          className="bg-primary/80 text-white rounded-md py-1.5 px-3 font-bold text-base transition-colors duration-200 hover:bg-accent focus:bg-accent outline-none"
        >
          <i className="fas fa-search"></i>
        </button>
        <button onClick={toggleLanguage} className="bg-primary text-white rounded-md py-1.5 px-4 font-bold text-base transition-colors duration-200 hover:bg-accent focus:bg-accent outline-none">
          {language === 'en' ? 'ES' : 'EN'}
        </button>
        <button onClick={toggleTheme} className="bg-primary text-white rounded-md py-1.5 px-4 font-bold text-base transition-colors duration-200 hover:bg-accent focus:bg-accent outline-none capitalize">
          {theme === 'light' ? 'Dark' : 'Light'}
        </button>
      </div>
    </header>
  );
};

export default Header;