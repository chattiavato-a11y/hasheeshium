export { integrationConfig, type IntegrationConfig } from '../src/services/integrationConfig.js';
